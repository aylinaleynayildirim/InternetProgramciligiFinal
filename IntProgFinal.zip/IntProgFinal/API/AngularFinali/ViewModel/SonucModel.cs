﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularFinali.ViewModel
{
    public class SonucModel
    {
        public bool islem { get; set; }
        public string mesaj { get; set; }
    }
}