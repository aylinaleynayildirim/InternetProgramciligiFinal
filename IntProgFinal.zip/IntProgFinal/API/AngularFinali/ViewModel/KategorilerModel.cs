﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularFinali.ViewModel
{
    public class KategorilerModel
    {
        public int KategoriId { get; set; }
        public string KategoriAdi { get; set; }
        public int KatSoruSay { get; set; }
    }
    
}