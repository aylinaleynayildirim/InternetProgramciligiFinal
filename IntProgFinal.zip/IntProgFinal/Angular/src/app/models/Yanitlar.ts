export class Yanitlar{

    YanitId:number;
    YanitIcerik:string;
    YanitTarih:Date;
    UyeId:number;
    SoruId:number;
    KullaniciAdi: string;
    sBaslik: string;
}