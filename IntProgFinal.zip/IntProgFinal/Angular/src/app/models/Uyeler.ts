export class Uyeler{

    UyeId: number;
    KullaniciAdi: string;
    UyeMail: string;
    UyeTarih: Date;
    UyeYetki: number;
    UyeParola: string;
}