export class Kategoriler{

    KategoriId:number;
    KategoriAdi:string;
    KatSoruSay: number;

}