export class Sorular{
    SoruId:number;
    SoruBaslik:string;
    SoruIcerik:string;
    SoruTarih:Date;
    KategoriId:number;
    KategoriAdi:string;
    UyeKadi:string;
    UyeId: number;
}

